package com.wangjiatao.service.impl;
import com.wangjiatao.dao.AdminDao;
import com.wangjiatao.domain.Caiping;
import com.wangjiatao.domain.Jilu;
import com.wangjiatao.domain.User;
import com.wangjiatao.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("AdminServiceImpl")
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminDao Dao;

    @Override
    public List<Caiping> GetWholeMenu() {
        return Dao.GetWholeMenu();
    }

    @Override
    public int DeleteMenu(String caiping) {
        return Dao.DeleteMenu(caiping);
    }

    @Override
    public int updateMenu(String caiping, String caipingleibie, String des) {
        return Dao.updateMenu(caiping,caipingleibie,des);
    }

    @Override
    public List<Jilu> getjil1() {
        return Dao.Getjilu1();
    }

    @Override
    public List<Jilu> getjil2() {
        return Dao.Getjilu2();
    }

    @Override
    public int DeleteJIlu(String caiping) {
        return Dao.DeleteJilu(caiping);
    }

    @Override
    public int updateadopt(String caiping) {
        return Dao.updateadopt(caiping);
    }

    @Override
    public int updaterevoke(String caiping) {
        return Dao.updaterevoke(caiping);
    }

    @Override
    public int register(String username, String password) {
        return Dao.register(username,password);
    }

    @Override
    public User login(String username, String password) {
        return Dao.login(username,password);
    }

    @Override
    public int updatepassword(String username, String password) {
        return Dao.updatePassword(username,password);
    }

}
