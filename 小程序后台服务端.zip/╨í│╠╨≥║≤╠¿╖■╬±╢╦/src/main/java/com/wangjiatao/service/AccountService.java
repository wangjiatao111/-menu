package com.wangjiatao.service;

import com.wangjiatao.domain.*;
import java.util.List;

public interface AccountService {
    public  void InsertCollection(yonghu Collection);
    public  List<step> LookupStep(String cai);
    public  List<Caiping> FindDishes();
    public void InsertCollection2(Caiping menu);
    public  List<Caiping> FindByCategory(String ClassificationOfDishes);
    public  List<yonghu> findbyopenid(String openid);
    public  void InsertionStep(step Collection);
    public  List<Caiping> FuzzyQuery(String KeyWord);
    public  void Delete(String openid ,String varietyOfDishes);
    public  void Insertionstaple(staple Collection);
    public  List<staple> LookupStaple(String cai);
    public  void ccount(String varietyOfDishes);
    public yonghu ste(String openid, String caiping);
    public  void Insertjilu(Jilu op);
    public  List<Jilu> fingyonghu(String openid);
    public void Delete2(String openid ,String varietyOfDishes);

    public  List<Jilu> fingyonghu2();
}
