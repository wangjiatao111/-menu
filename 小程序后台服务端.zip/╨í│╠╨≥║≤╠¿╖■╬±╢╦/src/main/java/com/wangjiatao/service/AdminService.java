package com.wangjiatao.service;


import com.wangjiatao.domain.Caiping;
import com.wangjiatao.domain.Jilu;
import com.wangjiatao.domain.User;

import java.util.List;

public interface AdminService {
    public  List<Caiping> GetWholeMenu();
    public int DeleteMenu(String caiping);
    public int updateMenu(String caiping,String caipingleibie,String des);
    public List<Jilu> getjil1();
    public  List<Jilu> getjil2();
    public int DeleteJIlu(String caiping);
    public int updateadopt(String caiping);
    public int updaterevoke(String caiping);
    public int register(String username,String password);
    public User login(String username, String password);
    public int updatepassword(String username, String password);
}
