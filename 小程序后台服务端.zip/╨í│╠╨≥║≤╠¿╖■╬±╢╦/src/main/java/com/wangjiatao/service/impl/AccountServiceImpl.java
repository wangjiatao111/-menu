package com.wangjiatao.service.impl;
import com.wangjiatao.dao.AccountDao;
import com.wangjiatao.domain.*;
import com.wangjiatao.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("AccountService")
public class AccountServiceImpl implements AccountService {
@Autowired
    private AccountDao dao;

    @Override
    public void InsertCollection(yonghu Collection) {
        dao.InsertCollection(Collection);
    }

    @Override
    public List<step> LookupStep(String cai) {
        return dao.LookupStep(cai);
    }

    @Override
    public List<Caiping> FindDishes() {
        return dao.FindDishes();
    }

    @Override
    public void InsertCollection2(Caiping menu) {
        dao.InsertCollection2(menu);
    }

    @Override
    public List<Caiping> FindByCategory(String caipingleibie) {
        System.out.println("sss"+dao.FindByCategory(caipingleibie));
        return dao.FindByCategory(caipingleibie);
    }

    @Override
    public List<yonghu> findbyopenid(String openid) {
        return dao.findbyopenid(openid);
    }

    @Override
    public void InsertionStep(step Collection) {
        dao.InsertionStep(Collection);
    }

    @Override
    public List<Caiping> FuzzyQuery(String KeyWord) {
        return dao.FuzzyQuery(KeyWord);
    }

    @Override
    public void Delete(String openid, String varietyOfDishes) {
        dao.Delete(openid, varietyOfDishes);
    }

    @Override
    public void Insertionstaple(staple Collection) {
        dao.Insertionstaple(Collection);
    }

    @Override
    public List<staple> LookupStaple(String cai) {
        System.out.println("执行LookupStaple");
        return dao.LookupStaple(cai);
    }

    @Override
    public void ccount(String varietyOfDishes) {
        dao.ccount(varietyOfDishes);
    }

    @Override
    public yonghu ste(String openid, String caiping) {
        return dao.ste(openid, caiping);
    }

    @Override
    public void Insertjilu(Jilu op) {
        dao.Insertjilu(op);
    }

    @Override
    public List<Jilu> fingyonghu(String openid) {
        return dao.fingyonghu(openid);
    }

    @Override
    public void Delete2(String openid, String varietyOfDishes) {
        dao.Delete2(openid, varietyOfDishes);
    }

    @Override
    public List<Jilu> fingyonghu2() {
        return dao.fingyonghu2();
    }
}
