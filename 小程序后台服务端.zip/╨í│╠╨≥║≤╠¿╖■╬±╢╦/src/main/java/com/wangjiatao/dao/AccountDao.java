package com.wangjiatao.dao;
import com.wangjiatao.domain.*;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;
/**
 * dao接口
 */
@Repository
public interface AccountDao {
    @Insert("insert into yonghu values(#{openid},#{caiping},#{tupian},#{ct},#{des})")
    public  void InsertCollection(yonghu Collection);

    @Select("select * from buzhou where caiping=#{cai}")
    public List<step> LookupStep(String cai);

    @Select("select * from caiping")
    public  List<Caiping> FindDishes();

    @Insert("insert into caiping values(#{caiping},#{tupian},#{caipingleibie},#{ct},#{des},#{count})")
    public void InsertCollection2(Caiping menu);


    @Select("select * from caiping where caipingleibie=#{caipingleibie}")
    public  List<Caiping> FindByCategory(String caipingleibie);

    @Select("select * from yonghu where openid=#{openid}")
    public List<yonghu> findbyopenid(String openid);

    @Insert("insert into buzhou values(#{caiping},#{buzhou},#{tupian})")
    public  void InsertionStep(step Collection);

    @Select("select * from caiping where caiping like #{KeyWord}")
    public  List<Caiping> FuzzyQuery(String KeyWord);

    @Delete("delete from yonghu where openid=#{openid} and caiping=#{varietyOfDishes}")
    public void Delete(@Param("openid") String openid ,@Param("varietyOfDishes") String varietyOfDishes);

    @Insert("insert into stap values(#{caiping},#{name},#{unit})")
    public void Insertionstaple(staple Collection);

    @Select("select * from stap where caiping=#{cai}")
    public List<staple> LookupStaple(String cai);

    @Update(" update caiping set count=count+1 where caiping = #{varietyOfDishes}")
    public void ccount(String varietyOfDishes);

    @Select("select * from yonghu where openid=#{openid} and caiping=#{caiping}")
    public   yonghu ste(@Param("openid") String openid,@Param("caiping")  String caiping);

    @Insert("insert into Jilu values(#{openid},#{caiping},#{miaoshu},#{riqi},#{yuanliao},#{buzhou},#{tupian},0)")
    public  void Insertjilu(Jilu op);

    @Select("select * from jilu where openid=#{openid}")
    public  List<Jilu> fingyonghu(String openid);

    @Delete("delete from jilu where openid=#{openid} and caiping=#{varietyOfDishes}")
    public void Delete2(@Param("openid") String openid ,@Param("varietyOfDishes") String varietyOfDishes);

    @Select("select * from jilu where whe=1")
    public  List<Jilu> fingyonghu2();

}
