package com.wangjiatao.dao;

import com.wangjiatao.domain.Caiping;
import com.wangjiatao.domain.Jilu;
import com.wangjiatao.domain.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface AdminDao {
    @Select("select * from caiping")
    public List<Caiping> GetWholeMenu();
    @Delete("delete from caiping where caiping=#{caiping}")
    public int DeleteMenu(@Param("caiping") String caiping);
    @Update("update caiping set caiping=#{caiping},caipingleibie=#{caipingleibie},des=#{des} where caiping = #{caiping}")
    public int updateMenu(@Param("caiping") String caiping, @Param("caipingleibie") String caipingleibie, @Param("des") String des);
    @Select("select * from jilu where whe=1")
    public  List<Jilu> Getjilu1();
    @Select("select * from jilu where whe=0")
    public List<Jilu> Getjilu2();
    @Delete("delete from jilu where caiping=#{caiping}")
    public int DeleteJilu(@Param("caiping") String caiping);
    @Update("update jilu set whe=1 where caiping = #{caiping}")
    public int updateadopt(@Param("caiping") String caiping);
    @Update("update jilu set whe=0 where caiping = #{caiping}")
    public int updaterevoke(@Param("caiping") String caiping);
    @Insert("insert into user(username,password) values(#{username},#{password})")
    public  int register(@Param("username") String username,@Param("password") String password);
    @Select("select * from user where username = #{username} and password = #{password}")
    public User login(@Param("username") String username,@Param("password") String password);
    @Update("update user set password=#{password} where username = #{username}")
    public int updatePassword(@Param("username") String username,@Param("password") String password);
}
