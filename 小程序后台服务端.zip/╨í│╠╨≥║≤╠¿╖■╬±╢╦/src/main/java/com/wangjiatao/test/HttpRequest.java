package com.wangjiatao.test;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
public class HttpRequest {

    /**
     * 获取HTTP请求的响应body
     * @method sendGet:静态方法，发送GET请求
     * @method sendPost:静态方法，发送POST请求
     */
    public  String sendGet(String url, String param) {
        /**
         * 向指定URL发送GET请求
         * @param url:请求地址
         * @param param:请求参数，这里简单点，请直接拼接成key1=value1&key2=value2···
         * @return 响应的body
         */
        String result = "";
        BufferedReader in = null;
        try {
            String req = url + "?" + param;
            URL urlEncode = new URL(req);
            URLConnection conn = urlEncode.openConnection();
            // 设置部分header并发起连接
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.connect();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送GET请求出现异常！" + e);
            e.printStackTrace();
        }
        // finally块关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        return result;
    }
    public static String sendPost(String url, String param) {
        /**
         * 向指定URL发送POST请求
         * @param url:请求地址
         * @param param:请求参数，请求参数是 json字符串的形式。
         * @return 响应的body
         */
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL urlEncode = new URL(url);
            URLConnection conn = urlEncode.openConnection();
            // 设置部分header
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 以json格式发送body
            conn.setRequestProperty("content-type", "application/json");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取conn对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            out.print(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流,读取响应的body
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！" + e);
            e.printStackTrace();
        }
        // finally块关闭输出流、输入流
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result;
    }
}