package com.wangjiatao.test;
import com.wangjiatao.service.AccountService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class cs {

    @Test
    public void run1(){
        //加载配置文件
        ApplicationContext ac=new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        //获取对象
        AccountService as= (AccountService)ac.getBean("AccountService");
        //调用方法
      String  classificationOfDishes="腰果";
        System.out.println("sss"+ as.FindByCategory(classificationOfDishes));
    }
}
