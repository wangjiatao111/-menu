package com.wangjiatao.test;
import com.wangjiatao.dao.AccountDao;
import com.wangjiatao.domain.Caiping;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
public class TestMybatis {
    @Test
    public void run1(){
        try {
            //1.读取配置文件
            InputStream in = Resources.getResourceAsStream("applicationContext.xml");
            //2.创建SqlSessionFactory工厂
            SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
            SqlSessionFactory factory = builder.build(in);
            //3.使用工厂生产SqlSession对象
            SqlSession session = factory.openSession();
            //4.使用SqlSession创建Dao接口的代理对象
            AccountDao userDao = session.getMapper(AccountDao.class);
            //5.使用代理对象执行方法
            String aa="首页推荐";
            List<Caiping> account = userDao.FindByCategory(aa);
            for(Caiping user : account){
                System.out.println(user);
            }
            //6.释放资源
            session.close();
            in.close();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

}
