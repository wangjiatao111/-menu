package com.wangjiatao.domain;

public class step {
    private String caiping;
    private String buzhou;
    private String tupian;
    public String getCaiping() {
        return caiping;
    }

    public void setCaiping(String caiping) {
        this.caiping = caiping;
    }

    public String getBuzhou() {
        return buzhou;
    }

    public void setBuzhou(String buzhou) {
        this.buzhou = buzhou;
    }

    public String getTupian() {
        return tupian;
    }

    public void setTupian(String tupian) {
        this.tupian = tupian;
    }

    @Override
    public String toString() {
        return "step{" +
                "caiping='" + caiping + '\'' +
                ", buzhou='" + buzhou + '\'' +
                ", tupian='" + tupian + '\'' +
                '}';
    }
}
