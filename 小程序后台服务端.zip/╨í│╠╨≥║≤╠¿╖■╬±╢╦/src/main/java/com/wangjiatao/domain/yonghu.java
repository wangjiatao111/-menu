package com.wangjiatao.domain;
public class yonghu {
    private String openid;
    private  String caiping;
    private String tupian;
    private String ct;
    private String des;
    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getCaiping() {
        return caiping;
    }

    public void setCaiping(String caiping) {
        this.caiping = caiping;
    }

    public String getTupian() {
        return tupian;
    }

    public void setTupian(String tupian) {
        this.tupian = tupian;
    }

    public String getCt() {
        return ct;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    @Override
    public String toString() {
        return "User{" +
                "openid='" + openid + '\'' +
                ", caiping='" + caiping + '\'' +
                ", tupian='" + tupian + '\'' +
                ", ct='" + ct + '\'' +
                ", des='" + des + '\'' +
                '}';
    }
}
