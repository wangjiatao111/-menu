package com.wangjiatao.domain;

public class Jilu {
    private String caiping;
    private String miaoshu;
    private String riqi;
    private String  yuanliao;
    private  String buzhou;
    private  String tupian;
     private String openid;
     private  String whe;
    public String getCaiping() {
        return caiping;
    }

    public void setCaiping(String caiping) {
        this.caiping = caiping;
    }

    public String getMiaoshu() {
        return miaoshu;
    }

    public void setMiaoshu(String miaoshu) {
        this.miaoshu = miaoshu;
    }

    public String getRiqi() {
        return riqi;
    }

    public void setRiqi(String riqi) {
        this.riqi = riqi;
    }

    public String getYuanliao() {
        return yuanliao;
    }

    public void setYuanliao(String yuanliao) {
        this.yuanliao = yuanliao;
    }

    public String getBuzhou() {
        return buzhou;
    }

    public void setBuzhou(String buzhou) {
        this.buzhou = buzhou;
    }

    public String getTupian() {
        return tupian;
    }

    public void setTupian(String tupian) {
        this.tupian = tupian;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getWhe() {
        return whe;
    }

    public void setWhe(String whe) {
        this.whe = whe;
    }

    @Override
    public String toString() {
        return "Jilu{" +
                "caiping='" + caiping + '\'' +
                ", miaoshu='" + miaoshu + '\'' +
                ", riqi='" + riqi + '\'' +
                ", yuanliao='" + yuanliao + '\'' +
                ", buzhou='" + buzhou + '\'' +
                ", tupian='" + tupian + '\'' +
                ", openid='" + openid + '\'' +
                ", whe='" + whe + '\'' +
                '}';
    }
}
