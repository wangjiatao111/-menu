package com.wangjiatao.domain;

public class staple {
    private String caiping;
    private String name;
    private String unit;
    public String getCaiping() {
        return caiping;
    }

    public void setCaiping(String caiping) {
        this.caiping = caiping;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "staple{" +
                "caiping='" + caiping + '\'' +
                ", name='" + name + '\'' +
                ", unit='" + unit + '\'' +
                '}';
    }
}
