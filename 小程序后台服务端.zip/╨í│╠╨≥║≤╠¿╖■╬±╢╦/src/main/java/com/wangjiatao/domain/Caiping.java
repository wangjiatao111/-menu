package com.wangjiatao.domain;

public class Caiping {
    private String caiping;
    private String tupian;
    private String caipingleibie;
    private String ct;
    private String des;
    private int count;
    public String getCaiping() {
        return caiping;
    }

    public void setCaiping(String caiping) {
        this.caiping = caiping;
    }

    public String getTupian() {
        return tupian;
    }

    public void setTupian(String tupian) {
        this.tupian = tupian;
    }

    public String getCaipingleibie() {
        return caipingleibie;
    }

    public void setCaipingleibie(String caipingleibie) {
        this.caipingleibie = caipingleibie;
    }

    public String getCt() {
        return ct;
    }

    public void setCt(String ct) {
        this.ct = ct;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "Caiping{" +
                "caiping='" + caiping + '\'' +
                ", tupian='" + tupian + '\'' +
                ", caipingleibie='" + caipingleibie + '\'' +
                ", ct='" + ct + '\'' +
                ", des='" + des + '\'' +
                ", count=" + count +
                '}';
    }
}
