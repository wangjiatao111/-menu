package com.wangjiatao.controller;
import com.wangjiatao.domain.Caiping;
import com.wangjiatao.domain.Jilu;
import com.wangjiatao.domain.User;
import com.wangjiatao.domain.yonghu;
import com.wangjiatao.service.AccountService;
import com.wangjiatao.test.HttpRequest;

import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Result;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;


@Controller
@RequestMapping("/account")
public class AccountController {
    private Logger logger = (Logger) Logger.getLogger(String.valueOf(AccountController.class));
    @Autowired
    private AccountService service2;

    @RequestMapping("/Servleti10")
    public void DeleteCollection(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String openid = request.getParameter("openid");
        String varietyOfDishes = request.getParameter("caiping");
        service2.Delete(openid, varietyOfDishes);
    }

    @RequestMapping("/Servleti16")
    public void Deletefabu(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String openid = request.getParameter("openid");
        String varietyOfDishes = request.getParameter("caiping");
        service2.Delete2(openid, varietyOfDishes);
    }

    @RequestMapping("/Servleti8")
    public void FuzzyQuery(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String KeyWord = request.getParameter("x");
        JSONArray array = JSONArray.fromObject(service2.FuzzyQuery("%" + KeyWord + "%"));
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti6")
    public void GetMenu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String classificationOfDishes = request.getParameter("x");

        JSONArray array = JSONArray.fromObject(service2.FindByCategory(classificationOfDishes));

        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servletil")
    public void GetOpenid(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String JSCODE = request.getParameter("code");
        String APPID = request.getParameter("from");
        String SECRET = request.getParameter("secret");
        String grant_type = "authorization_code";
        HttpRequest httpRequest = new HttpRequest();
        String params = "appid=" + APPID + "&secret=" + SECRET + "&js_code=" + JSCODE + "&grant_type=" + grant_type;
        String UserInformation = httpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        System.out.println(UserInformation);
        Writer out = response.getWriter();
        out.write(UserInformation);
    }

    @RequestMapping("/Servleti11")
    public void Getstaple(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String staple = request.getParameter("x");
        JSONArray array = JSONArray.fromObject(service2.LookupStaple(staple));
        System.out.println("没有什么" + array);
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti15")
    public void huoqu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String openid = request.getParameter("openid");
        JSONArray array = JSONArray.fromObject(service2.fingyonghu(openid));
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti151")
    public void huoqu2(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        JSONArray array = JSONArray.fromObject(service2.fingyonghu2());
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti12")
    public void increase(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String classificationOfDishes = request.getParameter("caiping");
        System.out.println("Servleti12执行了");
        service2.ccount(classificationOfDishes);
    }

    @RequestMapping("/Servleti13")
    public void Judge(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping = request.getParameter("x");
        String openid = request.getParameter("y");
        System.out.println("小程序的openid是" + openid + "小程序读分菜谱是" + caiping);
        System.out.println("Servleti13执行了");
        if (service2.ste(openid, caiping) != null) {
            System.out.println("Servleti13执行了22");
            JSONArray array = JSONArray.fromObject(service2.ste(openid, caiping));
            Writer out = response.getWriter();
            System.out.println("Servleti13执行了222222222");
            out.write(String.valueOf(array));
        }
    }

    @RequestMapping("/Servleti3")
    public void QuerySteps(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String varietyOfDishes = request.getParameter("x");
        JSONArray array = JSONArray.fromObject(service2.LookupStep(varietyOfDishes));
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti2")
    public void ReturnRecipes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        List<Caiping> Menu = service2.FindDishes();
        JSONArray array = JSONArray.fromObject(Menu);
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti7")
    public void ReturnUserInformation(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String openid = request.getParameter("x");
        JSONArray array = JSONArray.fromObject(service2.findbyopenid(openid));
        System.out.println(array);
        Writer out = response.getWriter();
        out.write(String.valueOf(array));
    }

    @RequestMapping("/Servleti5")
    public void shoucang(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("Servleti5执行了");
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String openid = request.getParameter("openid");
        String varietyOfDishes = request.getParameter("caiping");
        String picture = request.getParameter("tupian");
        String ct = request.getParameter("ct");
        String des = request.getParameter("des");
        yonghu collection = new yonghu();
        collection.setOpenid(openid);
        collection.setCaiping(varietyOfDishes);
        collection.setTupian(picture);
        collection.setCt(ct);
        collection.setDes(des);
        service2.InsertCollection(collection);
    }


    @RequestMapping(value = "/uploadFile",method=RequestMethod.POST )
    @ResponseBody
    public void upload(MultipartFile file, HttpServletRequest request){
        Jilu yonghu = new Jilu();
        String openid = request.getParameter("openid");
        yonghu.setOpenid(openid);
        String caiping = request.getParameter("caiping");
        yonghu.setCaiping(caiping);
        String miaoshu = request.getParameter("miaoshu");
        yonghu.setMiaoshu(miaoshu);
        String riqi = request.getParameter("riqi");
        yonghu.setRiqi(riqi);
        String yuanliao = request.getParameter("yuanliao");
        yonghu.setYuanliao(yuanliao);
        String buzhou = request.getParameter("buzhou");
        yonghu.setBuzhou(buzhou);


        //文件的扩展名
        String originalFilename = file.getOriginalFilename();
        String extName=originalFilename.substring(originalFilename.lastIndexOf("."));
        String user=request.getParameter("user");
        System.out.println(user);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSS");
        String res = sdf.format(new Date());

        // 新文件名
        String newFileName = "wx" + res + extName;

        // upload文件夹位置,webapp下
        String rootPath = request.getSession().getServletContext().getRealPath("upload/");
        System.out.println(rootPath);
        //获取协议名+域名+端口号+项目名 = http+"://"+localhost+":"+8080+/booksystem
        String url= request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
        System.out.println(url);
        try{
            // 创建年月文件夹
            Calendar date = Calendar.getInstance();
            File dateDirs = new File(date.get(Calendar.YEAR) + File.separator + (date.get(Calendar.MONTH)+1));
            // 新文件
            File newFile = new File(rootPath + File.separator + dateDirs + File.separator + newFileName);
            // 判断目标文件所在目录是否存在
            if( !newFile.getParentFile().exists()) {
                // 如果目标文件所在的目录不存在，则创建父目录
                newFile.getParentFile().mkdirs();
            }
            // 将内存中的数据写入磁盘
            file.transferTo(newFile);
            // 完整的url
            String fileUrl = url+"/upload/"+ date.get(Calendar.YEAR) + "/" + (date.get(Calendar.MONTH)+1) + "/" + newFileName;
            yonghu.setTupian(fileUrl);
            System.out.println(yonghu);
            service2.Insertjilu(yonghu);

        }catch(Exception e){
            e.printStackTrace();

        }

    }


}