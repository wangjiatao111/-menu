package com.wangjiatao.controller;
import com.wangjiatao.domain.User;
import com.wangjiatao.service.AdminService;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;
    ///1.获取CaiPing表所有信息
    @RequestMapping("/getWholeMenu")
    public void GetWholeMenu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        JSONArray array = JSONArray.fromObject(adminService.GetWholeMenu());
        int total =array.size();
        //需要返回的数据有总记录数和行数据
        String json = "{\"total\":" + total + ",\"rows\":" + array + "}";
        Writer out =response.getWriter();
        out.write(String.valueOf(json));
    }
    ///2.删除CaiPing表的某一行
    @RequestMapping("/deleteMenu")
    public void DeleteMenu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping=request.getParameter("caiping");
        int re=adminService.DeleteMenu(caiping);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///3.修改CaiPing表的某一行
    @RequestMapping("/updateMenu")
    public void UpdateMenu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping=request.getParameter("caiping");
        String caipingleibie=request.getParameter("caipingleibie");
        String des=request.getParameter("des");
        int re=adminService.updateMenu(caiping,caipingleibie,des);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///4.获取已发布的jilu表
    @RequestMapping("/getjilu1")
    public void Getjilu1(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        JSONArray array = JSONArray.fromObject(adminService.getjil1());
        int total =array.size();
        //需要返回的数据有总记录数和行数据
        String json = "{\"total\":" + total + ",\"rows\":" + array + "}";
        Writer out =response.getWriter();
        out.write(String.valueOf(json));
    }
    ///4.获取未发布的jilu表
    @RequestMapping("/getjilu2")
    public void Getjilu2(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        JSONArray array = JSONArray.fromObject(adminService.getjil2());
        int total =array.size();
        //需要返回的数据有总记录数和行数据
        String json = "{\"total\":" + total + ",\"rows\":" + array + "}";
        Writer out =response.getWriter();
        out.write(String.valueOf(json));
    }
    ///5.删除jilu表的某一行
    @RequestMapping("/deleteJilu")
    public void DeleteJilu(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping=request.getParameter("caiping");
        int re=adminService.DeleteJIlu(caiping);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///6.修改jilu表的whe
    @RequestMapping("/updateadopt")
    public void Updateadopt(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping=request.getParameter("caiping");
        int re=adminService.updateadopt(caiping);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///6.修改jilu表的whe
    @RequestMapping("/updaterevoke")
    public void Updaterevoke(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String caiping=request.getParameter("caiping");
        int re=adminService.updaterevoke(caiping);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///7.注册
    @RequestMapping("/register")
    public void Register(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        System.out.println(username+password);
        int re=adminService.register(username,password);
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///8.登录
    @RequestMapping("/login")
    public void Login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        User user =adminService.login(username,password);
        System.out.println(user);
        int re;
        if(user!=null){
            re=1;
        }
        else {
            re=0;
        }
        Writer out =response.getWriter();
        out.write(String.valueOf(re));
    }
    ///9.修改密码
    @RequestMapping("updatePassword")
    public void UpdatePassword(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int re = adminService.updatepassword(username, password);
        Writer out = response.getWriter();
        out.write(String.valueOf(re));
    }
}
