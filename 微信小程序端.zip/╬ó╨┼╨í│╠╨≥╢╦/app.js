//app.js
App({
  globalData: {
    openid: '',
  },
  onLaunch: function () {
    // 展示本地存储能力
   
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        console.log("hhshs"+res.code)
        wx.request({
          url: getApp().globalData.url+'Servletil',
          data: {
            'code': res.code,
            'from': 'wx3963d1a4e2d197b4',
            'secret':'4e6d9e59a22983007fe36ad8a1a8bc3d'
          },
          success: function (res) {
         //将 SESSIONID 保存到本地 storage
            wx.setStorageSync('OPENID', res.data.openid)
          },
          fail: function (res) {
            console.log('res' + res)
          }
        })
      }
    })

  },
  //快递查询
  getExpressInfo: function (nu, cb) {
    wx.request({
      url: 'https://ali-deliver.showapi.com/showapi_expInfo?com=auto&nu=' + nu,
      data: {

      },
      header: {
        'Authorization': 'APPCODE 8d71c88894144e798b37278667f2c286'
      },
      success: function (res) {
        cb(res.data)
      },
      false:function(){
            cb('查询失败')
      }
    })
  },
  globalData: {
    userInfo: null,
    url:"https://www.gpnujky.top:8445/wjt/account/"

  }
})