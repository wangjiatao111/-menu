//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    motto: 'Hello World',
    currentIndex: 0,
    userInfo: {},
    hasUserInfo: false,
    texts:[
        {text:"快递查询"},
        {text:"天气预报"}
        ],
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    openid: '',
    collectList: [],
    variety: [],
    query: '',
    as: []
  },
  onLoad: function () {
    
    //判断用户是否登录
    if (app.globalData.userInfo) {
      console.log("已登录");
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      console.log("未登录2");
      console.log(app.globalData.userInfo);
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        console.log("未登录2");
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      console.log("版本不兼容");
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  bindgetUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  //swiper切换时会调用
  pagechange: function (e) {
    if ("touch" === e.detail.source) {
      let currentPageIndex = this.data.currentIndex
      currentPageIndex = (currentPageIndex + 1) % 2
      this.setData({
        currentIndex: currentPageIndex
      })
    }
  },
  //用户点击tab时调用
  titleClick: function (e) {
    let currentPageIndex =
      this.setData({
        //拿到当前索引并动态改变
        currentIndex: e.currentTarget.dataset.idx
      })
  },
  kantie: function (e) {
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    console.log(ccc.caiping.caiping);
    wx.navigateTo({
      url: '/pages/step/step?id=' + ccc.caiping.caiping + '&p=' + ccc.caiping.yuanliao + '&p2=' + ccc.caiping.fuliao + '&p3=' + ccc.caiping.tupian
    })
  },
  longPress: function (e) {
    var that = this;
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    wx.showModal({ //使用模态框提示用户进行操作
      title: '警告',
      content: '你将删除此收藏！',
      success: function (res) {

        if (res.confirm) { //判断用户是否点击了确定
          console.log(ccc);
          wx.request({
            url:  getApp().globalData.url+'Servleti10',
            data: {
              openid: wx.getStorageSync('OPENID'),
              caiping: ccc.caiping.caiping
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                mask: true,
                duration: 700,
             })
              that.getcollect();
              console.log("成功")
            }
          })

        }

      }

    })

  },
  longPress2: function (e) {
    var that = this;
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    wx.showModal({ //使用模态框提示用户进行操作

      title: '警告',

      content: '你将删除此记录！',

      success: function (res) {

        if (res.confirm) { //判断用户是否点击了确定
          console.log("asasasasasssss"+ccc.caiping.caiping)
          wx.request({
            url:  getApp().globalData.url+'Servleti16',
            data: {
              openid: wx.getStorageSync('OPENID'),
              caiping: ccc.caiping.caiping
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            success(res) {
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                mask: true,
                duration: 700,
             })
              that.getData2();
              console.log("成功")
            }
          })

        }

      }

    })

  },
// 长按删除收藏的菜谱或者发布的菜谱

  getcollect() {
    var that = this
    wx.request({
      url:  getApp().globalData.url+'Servleti7',
      data: {
        x: wx.getStorageSync('OPENID')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res.data)
        that.setData({
          variety: res.data
        })
      }
    })

  },
// 返回顶部
// 获取滚动条当前位置
onPageScroll: function (e) {
  if (e.scrollTop > 50) {
    this.setData({
      floorstatus: true
    });
  } else {
    this.setData({
      floorstatus: false
    });
  }
},

//回到顶部
goTop: function (e) {  // 一键回到顶部
  if (wx.pageScrollTo) {
    wx.pageScrollTo({
      scrollTop: 0
    })
  } else {
    wx.showModal({
      title: '提示',
      content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
    })
  }
},


// 滚动到底部继续上拉加载更多（未实现）
 onReachBottom(){
console.log(123)
},
  //转发分享功能
  onShareAppMessage: function () {
    return {
      title: '唯有美食与爱不可辜负',
      desc: '千年文化传承，千年坎坷琢磨，中华美食，色香味美,中华小当家。',
      path: '/page/index?id=123'
    }
  }  ,
  onShow: function () {
    this.getcollect(),
    this.getData2()
  //  console.log(0)
  },
  getData2: function () {
    var that = this;
    wx.request({
      url: getApp().globalData.url+'Servleti15',
      data: {
        openid: wx.getStorageSync('OPENID')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res)
        that.setData({
          as: res.data
        })
      }
    })
  },
  kantie2: function (e) {
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    console.log("zhegahs" + ccc.caiping.buzhou)
    wx.navigateTo({
      url: '/pages/step2/step?id=' + ccc.caiping.caiping + '&p2=' + ccc.caiping.tupian + '&p3=' + ccc.caiping.riqi + '&p4=' + ccc.caiping.miaoshu + '&p5=' + ccc.caiping.yuanliao + '&p6=' + ccc.caiping.buzhou
    })
  },
  titleClick0: function () {
    wx.navigateTo({
      url: '/pages/express/express',
    })
  },
  titleClick1:function(){
    wx.navigateTo({
      url: '/pages/weather/weather',
    })
  },
  titleClick2:function(){
    wx.navigateTo({
      url: '/pages/postMenu/postMenu',
    })
  }
})
