const app = getApp()

Page({
  data: {
    files: [],
    max1: 500, //最多字数 (根据自己需求改变) 
    currentWordNumber1: 0,//监控输入了多少个字
    max2: 1000, //最多字数 (根据自己需求改变) 
    currentWordNumber2: 0,//监控输入了多少个字
    imgs: [],
    img: '',
    date: '请选择烹饪日期',
    caiping: '',
    miaoshu: '',
    yuanliao: '',
    buzhou: ''
  },


  // 日期选择函数
  bindDateChange: function (e) {
    this.setData({
      date: e.detail.value
    })
    console.log("做菜的日期是:" + this.data.date)
  },
  inputs1: function (e) {
    // 获取输入框的内容
    var value = e.detail.value;
    // 获取输入框内容的长度
    var len = parseInt(value.length);
    console.log(value)
    this.setData({
      caiping: value,
      currentWordNumber1: len //当前字数  
    });
    console.log("菜品名是:" + this.data.caiping)
  },
  inputs2: function (e) {
    // 获取输入框的内容
    var value = e.detail.value;
    // 获取输入框内容的长度
    var len = parseInt(value.length);
    console.log(value)
    this.setData({
      miaoshu: value,
      currentWordNumber1: len //当前字数  
    });
    console.log("菜品标签是:" + this.data.miaoshu)
  },
  // 文本域输入了多少个字
  inputs3: function (e) {
    // 获取输入框的内容
    var value = e.detail.value;
    // 获取输入框内容的长度
    var len = parseInt(value.length);
    console.log(value)
    this.setData({
      yuanliao: value,
      currentWordNumber1: len //当前字数  
    });
    console.log("菜品原料是:" + this.data.yuanliao)
  },
  // 文本域输入了多少个字
  inputs4: function (e) {
    // 获取输入框的内容
    var value = e.detail.value;
    // 获取输入框内容的长度
    var len = parseInt(value.length);
    this.setData({
      buzhou: value,
      currentWordNumber2: len //当前字数  
    });
    console.log("菜品步骤是:" + this.data.buzhou),
      console.log("tushi" + this.data.imgs)
  },


  //  图片上传函数
  chooseImage: function (e) {
    var that = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.setData({
          files: that.data.files.concat(res.tempFilePaths)
        });
      }
    })
  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.files // 需要预览的图片http链接列表
    })
  },




  //上传图片
  chooseImg: function (e) {
    var that = this;
    var imgs = this.data.imgs;
    if (imgs.length >= 1) {
      this.setData({
        lenMore: 1
      });
      setTimeout(function () {
        that.setData({
          lenMore: 0
        });
      }, 2500);
      return false;
    }
    wx.chooseImage({
      // count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        var imgs = that.data.imgs;
        // console.log(tempFilePaths + '----');
        for (var i = 0; i < tempFilePaths.length; i++) {
          if (imgs.length >= 1) {
            that.setData({
              imgs: imgs
            });
            return false;
          } else {
            imgs.push(tempFilePaths[i]);
          }
        }
        // console.log(imgs);
        that.setData({
          imgs: imgs
        });
      }
    });
  },
  // 删除图片
  deleteImg: function (e) {
    var that = this;
    var imgs = that.data.imgs;
    var index = e.currentTarget.dataset.index;//获取当前长按图片下标
    wx.showModal({
      title: '提示',
      content: '确定要删除此图片吗？',
      success: function (res) {
        if (res.confirm) {
          imgs.splice(index, 1);
        } else if (res.cancel) {
          return false;
        }
        that.setData({
          imgs: imgs
        });
      }
    })
  },
  // 预览图片
  previewImg: function (e) {
    //获取当前图片的下标
    var index = e.currentTarget.dataset.index;
    //所有图片
    var imgs = this.data.imgs;

    wx.previewImage({
      //当前显示图片
      current: imgs[index],
      //所有图片
      urls: imgs
    })
  },

  // 点击提交跳转到成功页面
  openSuccess: function () {
    var img = this.data.imgs[0]
    console.log( this.data.imgs[0])
    var that = this
    wx.uploadFile({
      url: getApp().globalData.url+'uploadFile', 
      filePath: that.data.imgs[0],
      name: 'file',
      formData: {
        'openid': wx.getStorageSync('OPENID'),
        'caiping': that.data.caiping,
        'miaoshu': that.data.miaoshu,
        'riqi': that.data.date,
        'yuanliao': that.data.yuanliao,
        'buzhou': that.data.buzhou
      },
      success: function (res) {
        var data = res.data
        console.log(data)
        setTimeout(function () {
           console.log("记录成功")
          //要延时执行的代码
          wx.switchTab({
            url: '/pages/user/user'
          })
        }, 1000) //延迟时间
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '热爱美食的人更热爱生活',
      desc: '生活不缺美食，只要告诉我你爱吃什么，我就能知道你是什么样的人',
      path: '/page/index?id=123'
    }
  },
});
