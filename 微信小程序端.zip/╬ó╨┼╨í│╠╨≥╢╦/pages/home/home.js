const App = getApp();
Page({
  data: {
    as: [],
    inputShowed: false,
    textes:
      [
        { text: '美食制作如此简单~~' },

      ],
    //滚动文字
    duration: 0, //水平滚动方法一中文字滚动总时间
    pace: 1.5,  //滚动速度
    msgList: [
      { url: "url", title: "新春出游必备，自加热营养餐！" },
      { url: "url", title: "美味好滋味，自己能体会~" },
      { url: "url", title: "懒人小菜，自己动手丰衣足食。" }],
    pictures: [
      { pictures: "/pictures/food4.jpg", name:'*冰淇淋一样的轻芝士蛋糕*' },
      { pictures: "/pictures/food3.jpg", name: '快手版自制香菇鸡块米线'},
      { pictures: "/pictures/food7.jpg", name: '家庭番茄火锅'},
      { pictures: "/pictures/food5.jpg", name: '咖喱鸡肉盖浇饭*'},
      { pictures: "/pictures/food6.jpg", name: '东北传统溜豆腐' },],

    category: [{
      id: "37",
      parentId: "1005",
      img: "/pictures/wu.png",
      name: '早餐'
    },
    {
      id: "38",
      parentId: "1005",
      img: "/pictures/zao.png",
      name: '午餐'
    },
    {
      id: "39",
      parentId: "1005",
      img: "/pictures/xiawu.png",
      name: '下午茶'
    },
    {
      id: "40",
      parentId: "1005",
      img: "/pictures/wan.png",
      name: '晚餐'
    },
    {
      id: "41",
      parentId: "1005",
      img: "/pictures/ye.png",
      name: '宵夜'
    }
    ],

    scroll: [{
      id: 1,
      parentId: "10001",
      img: "/pictures/jiachangcai.jpg",
      name: '家常菜'
    },
    {
      id: 2,
      parentId: "10001",
      img: "/pictures/kuaishoucai.jpg",
      name: '快手菜'
    },
    {
      id: 3,
      parentId: "10001",
      img: "/pictures/chuangyicai.jpg",
      name: '创意菜'
    },
    {
      id: 4,
      parentId: "10001",
      img: "/pictures/sucai.jpg",
      name: '素菜'
    },
    {
      id: 5,
      parentId: "10001",
      img: "/pictures/liangcai.jpg",
      name: '凉菜'
    }
    ],
  },

  showInput: function () {
    this.setData({
      inputShowed: true   //设置文本框可以输入内容
    });
  },
  // 取消搜索
  hideInput: function () {
    this.setData({
      inputShowed: false
    });
  },

  onShow: function () {
    let that = this;
    let windowWidth = wx.getSystemInfoSync().windowWidth; //屏幕宽度
    wx.createSelectorQuery().select('#txt1').boundingClientRect(function (rect) {
      let duration = rect.width * 0.04;//滚动文字时间,滚动速度为0.03s/px
      that.setData({
        duration: duration
      })
    }).exec()
  },
  onLoad: function (options) {
    
    this.getData()
  },
  getData: function () {
    var that = this;
    wx.request({
      url: getApp().globalData.url+'Servleti6',
      data: {
        x: '首页推荐'
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          as: res.data
        })
       
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '唯有美食与爱不可辜负',
      desc: '千年文化传承，千年坎坷琢磨，中华美食，色香味美。',
      path: '/page/index?id=123'
    }
  },
  goSearch(e) {
    wx.navigateTo({
      url: `/pages/search/search`,
    })
  },
  kantie: function (e) {
    var ccc = e.currentTarget.dataset.caiping;//获取view中的currentTarget
    console.log(ccc)
    wx.navigateTo({
      url: '/pages/category/category?flie=' + ccc
    })
  },
  kantie2: function (e) {
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    var that = this;
    wx.request({
      url:  getApp().globalData.url+'Servleti12',
      data: {
        caiping: ccc.caiping.caiping
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log("count更新成功")
      }
    })
    wx.navigateTo({
      url: '/pages/step/step?id=' + ccc.caiping.caiping + '&p3=' + ccc.caiping.tupian + '&p4=' + ccc.caiping.ct + '&p5=' + ccc.caiping.des
    })
  },
  kantie3: function (e) {
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    wx.navigateTo({
      url: '/pages/step/step?id=' + ccc.caiping.name + '&p3=' + ccc.caiping.pictures + '&p4=' + 'null' + '&p5=' + 'null'
    })
  },
  tiouzhuang:function(e){
    wx.switchTab({
      url: '/pages/menu/menu',
    })
  }
})
