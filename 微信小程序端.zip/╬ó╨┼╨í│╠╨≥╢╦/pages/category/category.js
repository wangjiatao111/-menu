Page({
  data: {
    as: [],
    name: ''
  },
  onLoad: function(options) {
    var that = this;
    that.setData({
      name: options.flie
    })
    this.getData();
  },
  getData: function() {
    var that = this;
    wx.request({
      url:  getApp().globalData.url+'Servleti6',
      data: {
        x: that.data.name
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          as: res.data
        })
       
      }
    })
  },
  kantie: function(e) {
    var ccc = e.currentTarget.dataset;
    var that = this;
    wx.request({
      url:  getApp().globalData.url+'Servleti12',
      data: {
        caiping: ccc.caiping.caiping
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log("count更新成功")
      }
    })
    wx.navigateTo({
      url: '/pages/step/step?id=' + ccc.caiping.caiping + '&p3=' + ccc.caiping.tupian + '&p4=' + ccc.caiping.ct + '&p5=' + ccc.caiping.des
    })
  },
})