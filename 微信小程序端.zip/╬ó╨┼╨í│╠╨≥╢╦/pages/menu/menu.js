const app = getApp()
Page({
  data: {
    cateItems: [
      {
        cate_id: 1,
        cate_name: '口味',
        children: [
          {
            child_id: 1,
            name: '辣',
            image: "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1586587146&di=9f6bdda66c0af9da5829e55025b7f1bb&src=http://pic1.win4000.com/wallpaper/a/5447458bdc730.jpg"
          },
          {
            child_id: 2,
            name: '咖喱',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2758341084,3441265211&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '糖醋',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1517342085,4097584828&fm=15&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '蒜香',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2699511703,688873732&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '奶香',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586597555304&di=cc6fed30aa2a7a37ac8503170aa1d325&imgtype=0&src=http%3A%2F%2Fm.360buyimg.com%2Fpop%2Fjfs%2Ft24775%2F102%2F192089247%2F25812%2F19bd28d4%2F5b68395cN61d40625.jpg"
          },
          {
            child_id: 2,
            name: '孜然',
            image: "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1608167370&di=6e82b054cb0aef41330066d395ac90d7&src=http://image-ali.bianjiyi.com/1/2017/1103/10/59fbd579da8f9.jpg"
          },
          {
            child_id: 2,
            name: '日式',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586597663288&di=68fb21b38641067e24c028624e0ce548&imgtype=0&src=http%3A%2F%2Fc.hiphotos.baidu.com%2Fbaike%2Fw%253D268%253Bg%253D0%2Fsign%3Dbafc7cd354e736d158138b0ea36b28ff%2F728da9773912b31bb2a3ff268618367adbb4e1f5.jpg"
          },
          {
            child_id: 2,
            name: '韩式',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586597684812&di=9fdea40363c4c18e907dfde8e0ded2a3&imgtype=0&src=http%3A%2F%2Fe.hiphotos.baidu.com%2Fbainuo%2Fcrop%3D0%2C16%2C1000%2C605%3Bw%3D720%3Bq%3D79%2Fsign%3D9d50bf1824f5e0fefa57d34161501899%2Faec379310a55b319868b32744aa98226cffc1744.jpg"
          },
          {
            child_id: 2,
            name: '西式',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=236014126,3920430658&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '西餐',
            image: "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1586857945&di=752cf4e05ff1e1d3ff63fe1258f8e3ed&src=http://hbimg.b0.upaiyun.com/c5dbc4e0db753ad67d2b1e2466efc576de3df33038744-ZH39JB_fw658"
          },
          {
            child_id: 2,
            name: '东南亚',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2848616729,1735323562&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '煎',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586597864131&di=ef94c6acc3665bfe747f359aab97cded&imgtype=0&src=http%3A%2F%2Fattachment2.jmw.com.cn%2Fimage%2F2019%2F03%2F25%2F15534865333044.jpg"
          },
          {
            child_id: 2,
            name: '蒸',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1861353486,4031448638&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '红烧',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586597940433&di=f773a7cabb5b3fb85baf082f4faec52c&imgtype=0&src=http%3A%2F%2Fimg.mp.itc.cn%2Fupload%2F20160707%2F3fd66cf50cdb452eaa87d171f2082f22_th.jpg"
          },
          {
            child_id: 2,
            name: '干锅',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3473719660,2016615822&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 2,
        cate_name: '特色食品',
        children: [
          {
            child_id: 1,
            name: '小吃',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598089992&di=b2aa7f8e4fafc30a448485fad4d43038&imgtype=0&src=http%3A%2F%2Fimages.china.cn%2Fattachement%2Fjpg%2Fsite1000%2F20111114%2F0019b91ec8ef102ad3c11c.jpg"
          },
          {
            child_id: 2,
            name: '沙拉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598172873&di=d124983177c4e35ea1ed09fcf9bf7b03&imgtype=0&src=http%3A%2F%2Fg.hiphotos.baidu.com%2Flbc%2Fpic%2Fitem%2F5fdf8db1cb134954d77b1cbd574e9258d0094a86.jpg"
          },
          {
            child_id: 2,
            name: '凉菜',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=4083802107,1761759675&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '零食',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598239573&di=092af87dc408d8b8ea2c0baed6718856&imgtype=0&src=http%3A%2F%2Fm.360buyimg.com%2Fpop%2Fjfs%2Ft24958%2F31%2F242630463%2F300658%2Fcfc00e54%2F5b697e3dN9bfbe508.png"
          },
          {
            child_id: 2,
            name: '三明治',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=135524818,2844181201&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '月饼',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=138795664,1757610963&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '蒸蛋',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1271093874,2111667221&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '寿司',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2826635744,675341116&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '粽子',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=317696304,4048115950&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸡蛋羹',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=786196158,2650125847&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 3,
        cate_name: '米面类',
        children: [
          {
            child_id: 1,
            name: '面条',
            image: "https://i8.meishichina.com/attachment/recipe/2017/02/09/2017020914866294334107513584.jpg?x-oss-process=style/p800"
          },
          {
            child_id: 2,
            name: '拌面',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598499510&di=7cfeb3eac4bc0f8424348b3c1c0569d5&imgtype=0&src=http%3A%2F%2Fwww.sdm0312.com%2FimageRepository%2F44b1e956-caf4-437b-9b98-7471fdad15f5.jpg"
          },
          {
            child_id: 2,
            name: '炒面',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1339326497,1471066163&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '汤面',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2256091049,308568696&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '凉面',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=574296717,2807144475&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '大米',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1842380261,1462682136&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '意大利面',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2209222788,153386461&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '低筋面粉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598666938&di=e56e684c14a8722be7166f836f83305c&imgtype=0&src=http%3A%2F%2Fimg.xuanchuanyi.com%2Fxuanchuanyi%2F20140910%2F9187a22211f1517c4ac293fb06ca1488.jpg"
          },
          {
            child_id: 2,
            name: '年糕',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3139357422,1177619326&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '糯米粉',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2816853198,3414567954&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '酒酿',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2713868906,1176976548&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '乌冬面',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1454851236,2904414397&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '小米',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586598969420&di=93548ea9b8d72cd2a5ad4c3fffc5adec&imgtype=0&src=http%3A%2F%2Fimg.alicdn.com%2Fimgextra%2Fi4%2F393441215%2FTB2LOwvcFXXXXaYXXXXXXXXXXXX-393441215.jpg"
          },
          {
            child_id: 2,
            name: '糯米',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3722955211,2103811356&fm=26&gp=0.jpg"
          }
        ]

      },
      {
        cate_id: 4,
        cate_name: '汤饭主食',
        children: [
          {
            child_id: 1,
            name: '炒饭',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3430181501,1350973706&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '饭团',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1636299772,527134021&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '盖浇饭',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2350500166,148534097&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '煲仔饭',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599153645&di=20a431a44d3b3ccdcf541d0748b601eb&imgtype=0&src=http%3A%2F%2Fp1.meituan.net%2Fdeal%2F8174e51b814dac73e46c9fed5be0fbeb122307.jpg"
          },
          {
            child_id: 2,
            name: '焗饭',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1132495445,3480488948&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '烩饭',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599194117&di=f682d565ccc78c8eeb86a5700395457d&imgtype=0&src=http%3A%2F%2Fcp2.douguo.net%2Fupload%2Fcaiku%2F3%2F6%2Fa%2Fyuan_366e342cd98567b75fcde3fe18917d2a.jpg"
          },
          {
            child_id: 2,
            name: '三明治',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599211669&di=82d3bd0c2f83aa5f2e9c0a30fe084853&imgtype=0&src=http%3A%2F%2Fp0.qhimg.com%2Ft01c01c0d8b7e77375b.jpg"
          },
          {
            child_id: 2,
            name: '馒头',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3301407718,1864814022&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '饺子',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599257224&di=78a4d0fc4bcdd97240a6df60dfe14bc7&imgtype=0&src=http%3A%2F%2Fbpic.588ku.com%2Felement_origin_min_pic%2F16%2F11%2F17%2F1a12cf9e989b9d05ca6cc11de4ddd221.jpg"
          },
          {
            child_id: 2,
            name: '馄饨',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=4285257896,1622478035&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '汤羹',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1910672616,4036335739&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '粥',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1333105082,2682992310&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '包子',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=220119721,2872000268&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '饼',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=4083411199,1459466272&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 5,
        cate_name: '烘培甜品饮料',
        children: [
          {
            child_id: 1,
            name: '蛋糕',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1055210772,2439959612&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '面包',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1661403141,112211023&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '饼干',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599493646&di=f1336f6840fe29ebfb9cca5b1f09492d&imgtype=0&src=http%3A%2F%2Fdpic.tiankong.com%2Fbf%2Fha%2FQJ6694184086.jpg%3Fx-oss-process%3Dstyle%2Fshow"
          },
          {
            child_id: 2,
            name: '披萨',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=133162993,451328032&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '司康',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2839639217,2600429636&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '泡芙',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=347402804,1842428761&fm=26&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '布丁',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1129918373,259247875&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '冷饮',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2835849570,3784900048&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '果酱',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599631306&di=764e2b5a0d037119b91215f0f7f1e7c9&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171123%2F8a6665c7659b4627bea11d04a5f97007.jpeg"
          },
          {
            child_id: 2,
            name: '糖水',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1447961896,3451391601&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '冰淇淋',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=157907501,667057856&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '果冻',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1608177620206&di=4db6115b224c48ca571dffe4c2c4b239&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201312%2F13%2F20131213191837_GCZyK.jpeg"
          },
          {
            child_id: 1,
            name: '咖啡',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2218897948,3862944921&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '豆浆',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3407256745,4064903311&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '奶茶',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586599754736&di=655698260bf7e4fb748a8f4561b58bab&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20170819%2Ffa20e89dc11f44feafef0ff09507930a.jpeg"
          },
          {
            child_id: 2,
            name: '酒',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3891897949,1715166836&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '果汁',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2292864712,3427679017&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '花草茶',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=510305162,1616548938&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 8,
        cate_name: '菜式',
        children: [
          {
            child_id: 1,
            name: '家常菜',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2154973895,2518053975&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '快手菜',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1317415248,644164700&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '下饭菜',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1097323587,1743065413&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '素菜',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600011955&di=4ccef6da62ec4a092bba89ffb44ae551&imgtype=0&src=http%3A%2F%2Fcp1.douguo.net%2Fupload%2Fcaiku%2F4%2F3%2F5%2Fyuan_43081806c01ac29bd1733eadd3f1e8f5.jpg"
          },
          {
            child_id: 2,
            name: '大鱼大肉',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2238762785,1833048223&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '下酒菜',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2275616534,2813494811&fm=11&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '小清新',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600086255&di=587b059884b18312c84c7ed15729ba04&imgtype=0&src=http%3A%2F%2Fi8.meishichina.com%2Fattachment%2Frecipe%2F2014%2F05%2F28%2F20140528105921914408967.jpg%3Fx-oss-process%3Dstyle%2Fp800"
          },
          {
            child_id: 2,
            name: '创意菜',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=106617433,3096717897&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 9,
        cate_name: '干果腌制',
        children: [
          {
            child_id: 1,
            name: '芝麻',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3382799196,142775734&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '花生',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2568157653,308109651&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '蔓越莓',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1294889181,2360224984&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '红豆',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2731360425,1137453527&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '绿豆',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=225180585,1765289266&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '黄豆',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1094970477,3391852315&fm=26&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '火腿',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1680066440,3146995591&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '香肠',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600367834&di=0281bed1e589df141c8ced60484e82d9&imgtype=0&src=http%3A%2F%2Fd8.yihaodianimg.com%2FV00%2FM00%2FA1%2F86%2FCgQDsFTwN4OAFXIYAAWBLdDjSkw18400.jpg"
          },
          {
            child_id: 2,
            name: '酸菜',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600382919&di=f1896e0aa152f3017680b48ee9cc2d43&imgtype=0&src=http%3A%2F%2Fimg.11665.com%2Fimg01_p%2Fi1%2FT110DGXl8iXXc9gyZ9_104053.jpg"
          },
          {
            child_id: 2,
            name: '肉松',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3537344211,2151614593&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '雪里蕻',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=473761540,1633427694&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '梅干菜',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2276485068,1584178964&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '腊肉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600449371&di=6d69599be8e8771a496683998a8a81b0&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171223%2F73eba79fb176413da3486d599ca2e607.jpeg"
          },
          {
            child_id: 2,
            name: '培根',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=862269406,1581547926&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '泡菜',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600480254&di=551f0e0f37ea7f0b7406c092ae708666&imgtype=0&src=http%3A%2F%2Fp.qiuxingwang.cn%2Fd%2Ffile%2Finveno%2F2016-08-04%2F7f2095b3df2a8976b8cf93bc1b8436cb.jpg"
          },
          {
            child_id: 2,
            name: '橄榄菜',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3418863578,131514919&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 11,
        cate_name: '蔬菜水果',
        children: [
          {
            child_id: 1,
            name: '时令水果',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3112350711,2866194088&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '柠檬',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3609119141,2054100990&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '草莓',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600637271&di=debf4a51cad5bfaaf2298a1e37360901&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F052dab73c247595ba6ce7bc6990af5a1b13ed88432cb1-HJTbkU_fw658"
          },
          {
            child_id: 2,
            name: '牛油果',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2690521824,293017989&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '木瓜',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2986275012,3653884871&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '芹菜',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586600714474&di=6888432feb2a7f563536f05092000e62&imgtype=0&src=http%3A%2F%2Fwww.lkkeji.cn%2FUserFile%2FCKImages%2F2018021311231247e1.png"
          },
          {
            child_id: 2,
            name: '白菜',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3718413076,2238544374&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '菠菜',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2173105480,505295605&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '西兰花',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2594287978,2057110139&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '圆白菜',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2457519326,3629383859&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '青椒',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1242594840,2827032128&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '番茄',
            image: "https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1586600787&di=fe5f4139612dd193967e2e94988a957b&src=http://5b0988e595225.cdn.sohucs.com/images/20170817/43e74dfed3064c839d8130facaf2a340.jpeg"
          },
          {
            child_id: 2,
            name: '玉米',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586610890652&di=9c1f7bfd13fbf50608e0f2972884625a&imgtype=0&src=http%3A%2F%2Fpic.pingguolv.com%2Fuploads%2Fallimg%2F180928%2F180-1P92Q54418.jpg"
          },
          {
            child_id: 2,
            name: '黄瓜',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586610909264&di=be9b09c9eb3fa590e55091e07b5a950e&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20170826%2F1d9fda664067497290f7f7c5d3a4fe86.jpeg"
          },
          {
            child_id: 2,
            name: '木瓜',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1896175803,3445633546&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '豇豆',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586610944176&di=e9602ea8b88a1b75a37680c583088207&imgtype=0&src=http%3A%2F%2Fimage4.suning.cn%2Fuimg%2Fb2c%2Fnewcatentries%2F0070182138-000000010119958677_3_800x800.jpg"
          }
        ]
      },
      {
        cate_id: 14,
        cate_name: '肉类',
        children: [
          {
            child_id: 1,
            name: '鸡翅',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3182530833,3455297333&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸡胸',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3056032912,893787946&fm=11&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '土鸡',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1965265249,878575212&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸡肝',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612549333&di=c458d9fb64a779f17da52c308121ab5d&imgtype=0&src=http%3A%2F%2Fdpic.tiankong.com%2Fdl%2Fsd%2FQJ6151144006.jpg%3Fx-oss-process%3Dstyle%2Fshow"
          },
          {
            child_id: 2,
            name: '鸡腿',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3151416452,309019143&fm=11&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸡爪',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2833603079,915039399&fm=11&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '猪肉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612603630&di=462d62e30b0ddd9c03a13c0aeca3bf65&imgtype=0&src=http%3A%2F%2Fstatic.caipiaogu.com%2Fimages%2Fzt%2F101%2Fzhurou.jpg"
          },
          {
            child_id: 2,
            name: '排骨',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612625253&di=761e563c64ce68a24ad59644758a2d89&imgtype=0&src=http%3A%2F%2F05imgmini.eastday.com%2Fmobile%2F20200312%2F20200312093415_17096a6f7f4f7344d99766562ae2ddc1_1.jpeg"
          },
          {
            child_id: 2,
            name: '里脊',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3459600711,1848856978&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '五花肉',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1947985424,1147556380&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '猪蹄',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1636292323,2403061879&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '猪肉末',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3070361564,4101615394&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '牛肉',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2031196660,462848204&fm=11&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '牛腩',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=731968371,1233388112&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '肥牛',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586611287657&di=d5917204077bbc934a14c2e6b855c2b3&imgtype=0&src=http%3A%2F%2Fpic1.16pic.com%2F00%2F21%2F90%2F16pic_2190174_b.jpg"
          },
          {
            child_id: 2,
            name: '牛里脊',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586611267905&di=306b5dae34c5c45fb3be5cc9d9ae241c&imgtype=0&src=http%3A%2F%2Fa4.att.hudong.com%2F63%2F16%2F01300000241358125853163078305.jpg"
          },
          {
            child_id: 2,
            name: '牛筋',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=203207299,258941260&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸭肉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586611231460&di=e7c367800b1e6b87ea3f9828b6c42569&imgtype=0&src=http%3A%2F%2Fimg0.d17.cc%2Ffile%2Fupload%2F201403%2F08%2F14-54-25-77-158297.jpg"
          },
          {
            child_id: 2,
            name: '老鸭',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1743170620,2863829610&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鸭翅',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=4236307528,1598525122&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '兔肉',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1666702848,2530020215&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '驴肉',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586611157777&di=42eb2d907135a14adeac4c9d0a9bc1f5&imgtype=0&src=http%3A%2F%2Ftu.ossfiles.cn%3A9186%2Fgroup2%2FM00%2F27%2FF1%2FrBgICV1A-ROAB3PNAAFXr9eC8h8678.jpg"
          },
          {
            child_id: 2,
            name: '雪鸽',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=776869079,2493628416&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鹅肉',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=874826582,1689934626&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 15,
        cate_name: '水产',
        children: [
          {
            child_id: 1,
            name: '虾',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3300798274,3807032961&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '虾仁',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2931621776,3458332599&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '海米',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2772673784,1892593670&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '明虾',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3450040090,1290993842&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '基围虾',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612883056&di=ee38b8113e3e39cb6641dcc5a1707077&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20180106%2F49a6dc86305a4b92ae87a09f1f494c97.jpeg"
          },
          {
            child_id: 2,
            name: '龙虾',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3465830064,1774509837&fm=11&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '小龙虾',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3066311070,2624504895&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '梭子蟹',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612943806&di=1ecd20e00fa57520564767637bed0cef&imgtype=0&src=http%3A%2F%2Fn.sinaimg.cn%2Fsinacn21%2F200%2Fw600h400%2F20180414%2Fb5b2-fzcyxmu6246731.jpg"
          },
          {
            child_id: 2,
            name: '大闸蟹',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586612964956&di=645ec1093a80c5208f436ba185ab0614&imgtype=0&src=http%3A%2F%2Fimg.xinxisea.com%2Fpublic%2Fpcimgs%2F3126%2F153274201499236.jpg"
          },
          {
            child_id: 2,
            name: '蟹肉',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=4280599623,711735016&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '蟹黄',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=3842338414,3676849585&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鲍鱼',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1768886627,2003955196&fm=26&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '牡蛎',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613080987&di=5c7841d742d8d24471de06daa911560c&imgtype=0&src=http%3A%2F%2Fimg.tupianzj.com%2Fuploads%2Fallimg%2F180719%2F22-1PG9134643-50.jpg"
          },
          {
            child_id: 2,
            name: '蛏子',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613102250&di=338907488bb331633a56d41b65a22798&imgtype=0&src=http%3A%2F%2Ffile.91sjlm.cn%2FUpload%2Fgngw%2FImages%2F1103063840920841.jpg"

          },
          {
            child_id: 2,
            name: '鲜贝',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=806421310,3633514444&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '北极贝',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=232269032,3006564072&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '海水鱼',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1118821754,1739446561&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '淡水鱼',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=4207919599,3835555019&fm=26&gp=0.jpg"
          }
        ]
      },
      {
        cate_id: 16,
        cate_name: '蛋奶豆制品',
        children: [
          {
            child_id: 1,
            name: '牛奶',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=1160346768,42813373&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '黄油',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613430651&di=4c7933cfb7e256feaa60e05f77f0d0f0&imgtype=0&src=http%3A%2F%2Fimg006.hc360.cn%2Fm4%2FM07%2F31%2F78%2FwKhQ6VSx2PCEMm6CAAAAABb3Mw0010.jpg"
          },
          {
            child_id: 2,
            name: '巧克力',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1367123960,3770158469&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '奶油',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613483584&di=ef620a3c7a726fcd5b8e83c629da158e&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171127%2F54dc85732b644f09921b0170f17a71eb.jpeg"
          },
          {
            child_id: 2,
            name: '奶酪',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1893829363,465403417&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '酸奶',
            image: "https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1284106855,834025426&fm=26&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '黑巧克力',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613536747&di=954c02c0cf749a78cab0d61caa968a1c&imgtype=0&src=http%3A%2F%2Fm.360buyimg.com%2Fn12%2Fjfs%2Ft2011%2F101%2F1637878495%2F237571%2Fb8d0e9%2F56d5763eN366f8454.jpg%2521q70.jpg"
          },
          {
            child_id: 2,
            name: '鸡蛋',
            image: "https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2693693860,3469738699&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '咸蛋',
            image: "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2739518055,1843551393&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '皮蛋',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1959426752,3253055258&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '鹌鹑蛋',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4286400695,160000871&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '豆腐',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2766273862,131773055&fm=26&gp=0.jpg"
          },
          {
            child_id: 1,
            name: '香干',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=4197292395,4182449849&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '豆渣',
            image: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1586613687449&di=9de40d096790553c34ebd86f173422cc&imgtype=0&src=http%3A%2F%2F5b0988e595225.cdn.sohucs.com%2Fimages%2F20171012%2F8b4cd3e57e2c44d085e92248e60bb2e4.jpeg"
          },
          {
            child_id: 2,
            name: '千张',
            image: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3235608184,561413496&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '腐竹',
            image: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2965677145,2211328050&fm=26&gp=0.jpg"
          },
          {
            child_id: 2,
            name: '素鸡',
            image: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3597612045,2529721681&fm=26&gp=0.jpg"
          }
        ]
      }

    ],
    curNav: 1,
    curIndex: 0
  },

  switchRightTab: function (e) {
    let id = e.target.dataset.id, index = e.target.dataset.index;
    this.setData({
      curNav: id,
      curIndex: index
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  kantie: function (e) {
    var ccc = e.currentTarget.dataset.caiping;//获取view中的currentTarget
    console.log(ccc);
    wx.navigateTo({
      url: '/pages/category/category?flie=' + ccc
    })
  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  onShareAppMessage: function () {
    return {
      title: '吃饱了才有力气减肥',
      desc: '生活不缺美食，懂得选择美食~',
      path: '/page/index?id=123'
    }
  },
})
