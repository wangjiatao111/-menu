// pages/fabu/fabu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    collectList: [],
    variety: [],
    query: '',
    as: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getData2()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getData2: function () {
    var that = this;
    wx.request({
      url: getApp().globalData.url+'Servleti151',
      data: {
       
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res)
        that.setData({
          as: res.data
        })
      }
    })
  },
 
  kantie2: function (e) {
    var ccc = e.currentTarget.dataset;//获取view中的currentTarget
    console.log("zhegahs" + ccc.caiping.buzhou)
    wx.navigateTo({
      url: '/pages/step2/step?id=' + ccc.caiping.caiping + '&p2=' + ccc.caiping.tupian + '&p3=' + ccc.caiping.riqi + '&p4=' + ccc.caiping.miaoshu + '&p5=' + ccc.caiping.yuanliao + '&p6=' + ccc.caiping.buzhou
    })
  },
})