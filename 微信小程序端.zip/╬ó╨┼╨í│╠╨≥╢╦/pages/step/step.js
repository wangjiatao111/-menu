// pages/ui/ui.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    materia: '',
    picture: '',
    ct:'',
    des:'',
    staple:[],
    cai:[],
   op:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
 

  onLoad: function(options) {
    var that = this;
    console.log("卡萨" + options.id + options.p3 + options.p4 + options.p5)

    that.setData({
      name: options.id,
      picture: options.p3,
      ct:options.p4,
      des:options.p5,
     
    })
    //向服务器获取制作步骤
    this.getcollect()
  },

  getcollect() {
    var that = this;
    wx.request({
      url:  getApp().globalData.url+'Servleti3',
      data: {
        x: that.data.name
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          //将数据保存进data中
          cai: res.data
        })
        console.log(that.data.cai)
      }
    })
    //向服务器获取制作原料
    wx.request({
      url:  getApp().globalData.url+'Servleti11',

      data: {
        x: that.data.name
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        that.setData({
          //将数据保存进data中
          staple: res.data
        })
      }
    })
    wx.request({
      url:  getApp().globalData.url+'Servleti13',
      data: {
        x: that.data.name,
        y: wx.getStorageSync('OPENID')
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log("返回的数据是" + res.data)

        that.setData({
          op: res.data
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
   
    return {
      title: '美食佳',
     
    }
  },
  kantie: function(e) {
    var ccc = this.data.name;
    var that = this;
    wx.request({
      url: getApp().globalData.url+'Servleti5',
      data: {
        openid: wx.getStorageSync('OPENID'),
        caiping: ccc,
        tupian: that.data.picture,
        ct: that.data.ct,
        des: that.data.des
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
          console.log("收藏成功")
        that.getcollect()
      }
    })
  }
})